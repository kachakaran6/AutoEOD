function h() {
  var t;
  try {
    const r = document.querySelector("title");
    if (r) {
      let e = r.textContent || "";
      if (e.endsWith(" - ChatGPT") && (e = e.substring(0, e.length - 10)), e !== "ChatGPT" && e !== "New chat" && e.trim() !== "")
        return e;
    }
    const n = document.querySelector("h1");
    if (n && ((t = n.textContent) == null ? void 0 : t.trim()) !== "") return n.textContent.trim();
  } catch (r) {
    console.warn("AutoEOD: Failed to parse title", r);
  }
  return "Untitled Conversation";
}
function g() {
  const t = window.location.pathname.match(/\/c\/([a-zA-Z0-9-]+)$/);
  return t ? t[1] : null;
}
function f() {
  try {
    const t = document.querySelector('button[aria-haspopup="menu"] .truncate, div.text-token-text-secondary.truncate');
    if (t && t.textContent)
      return t.textContent.trim();
  } catch {
  }
}
function p() {
  try {
    const t = document.querySelector('[data-testid="workspace-name"]');
    if (t && t.textContent)
      return t.textContent.trim();
  } catch {
  }
}
function y() {
  try {
    const t = document.querySelectorAll("[data-message-author-role]"), r = [];
    return t.forEach((n) => {
      const e = n.getAttribute("data-message-author-role") || "unknown", c = n.getAttribute("data-message-id") || void 0;
      let o = n.textContent || "";
      o = o.trim();
      const a = o.length > 500 ? o.substring(0, 500) + "..." : o, s = (/* @__PURE__ */ new Date()).toISOString();
      a && e && r.push({ id: c, role: e, excerpt: a, timestamp: s });
    }), r;
  } catch (t) {
    return console.warn("AutoEOD: Failed to extract messages", t), [];
  }
}
let d = null, u = null, i = null;
function b() {
  const t = g();
  if (!t) return;
  const r = h(), n = y(), e = f(), c = p();
  if (n.length === 0) return;
  const o = {
    externalId: t,
    title: r,
    lastSeenAt: (/* @__PURE__ */ new Date()).toISOString(),
    modelName: e,
    workspace: c,
    messages: n
  }, a = JSON.stringify(o);
  if (d !== a) {
    d = a;
    try {
      chrome.runtime.sendMessage({ type: "ACTIVITY_UPDATE", payload: o }, (s) => {
        chrome.runtime.lastError && console.warn("AutoEOD: Failed to send message to background script.", chrome.runtime.lastError);
      });
    } catch (s) {
      console.warn("AutoEOD: Error sending message", s);
    }
  }
}
function l() {
  u !== null && clearTimeout(u), u = setTimeout(b, 5e3);
}
function w() {
  i && i.disconnect(), i = new MutationObserver((r) => {
    let n = !1;
    for (const e of r)
      if (e.type === "childList" || e.type === "characterData") {
        n = !0;
        break;
      }
    n && l();
  });
  const t = document.querySelector("main") || document.body;
  i.observe(t, {
    childList: !0,
    subtree: !0,
    characterData: !0
  });
}
w();
setTimeout(() => {
  l();
}, 2e3);
let m = location.href;
new MutationObserver(() => {
  const t = location.href;
  t !== m && (m = t, l());
}).observe(document, { subtree: !0, childList: !0 });
