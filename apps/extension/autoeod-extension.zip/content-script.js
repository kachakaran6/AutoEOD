function h() {
  var t;
  try {
    const o = document.querySelector("title");
    if (o) {
      let e = o.textContent || "";
      if (e.endsWith(" - ChatGPT") && (e = e.substring(0, e.length - 10)), e !== "ChatGPT" && e !== "New chat" && e.trim() !== "")
        return e;
    }
    const n = document.querySelector("h1");
    if (n && ((t = n.textContent) == null ? void 0 : t.trim()) !== "") return n.textContent.trim();
  } catch (o) {
    console.warn("AutoEOD: Failed to parse title", o);
  }
  return "Untitled Conversation";
}
function g() {
  const t = window.location.pathname.match(/\/c\/([a-zA-Z0-9-]+)$/);
  return t ? t[1] : null;
}
function f() {
  try {
    const t = document.querySelector('button[aria-haspopup="menu"] .truncate, div.text-token-text-secondary.truncate');
    if (t && t.textContent)
      return t.textContent.trim();
  } catch {
  }
}
function p() {
  try {
    const t = document.querySelector('[data-testid="workspace-name"]');
    if (t && t.textContent)
      return t.textContent.trim();
  } catch {
  }
}
function y() {
  try {
    const t = document.querySelectorAll("[data-message-author-role]"), o = [];
    return t.forEach((n) => {
      const e = n.getAttribute("data-message-author-role") || "unknown", i = n.getAttribute("data-message-id") || void 0;
      let r = n.textContent || "";
      r = r.trim();
      const a = r.length > 500 ? r.substring(0, 500) + "..." : r, s = (/* @__PURE__ */ new Date()).toISOString();
      a && e && o.push({ id: i, role: e, excerpt: a, timestamp: s });
    }), o;
  } catch (t) {
    return console.warn("AutoEOD: Failed to extract messages", t), [];
  }
}
let d = null, u = null, c = null;
function b() {
  const t = g();
  if (!t) return;
  const o = h(), n = y(), e = f(), i = p(), r = {
    externalId: t,
    title: o,
    lastSeenAt: (/* @__PURE__ */ new Date()).toISOString(),
    modelName: e,
    workspace: i,
    messages: n
  }, a = JSON.stringify(r);
  if (d !== a) {
    d = a;
    try {
      chrome.runtime.sendMessage({ type: "ACTIVITY_UPDATE", payload: r }, (s) => {
        chrome.runtime.lastError && console.warn("AutoEOD: Failed to send message to background script.", chrome.runtime.lastError);
      });
    } catch (s) {
      console.warn("AutoEOD: Error sending message", s);
    }
  }
}
function l() {
  u !== null && clearTimeout(u), u = setTimeout(b, 5e3);
}
function w() {
  c && c.disconnect(), c = new MutationObserver((o) => {
    let n = !1;
    for (const e of o)
      if (e.type === "childList" || e.type === "characterData") {
        n = !0;
        break;
      }
    n && l();
  });
  const t = document.querySelector("main") || document.body;
  c.observe(t, {
    childList: !0,
    subtree: !0,
    characterData: !0
  });
}
w();
setTimeout(() => {
  l();
}, 2e3);
let m = location.href;
new MutationObserver(() => {
  const t = location.href;
  t !== m && (m = t, l());
}).observe(document, { subtree: !0, childList: !0 });
