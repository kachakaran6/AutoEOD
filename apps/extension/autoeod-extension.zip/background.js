const p = (e, t) => t.some((n) => e instanceof n);
let P, M;
function k() {
  return P || (P = [
    IDBDatabase,
    IDBObjectStore,
    IDBIndex,
    IDBCursor,
    IDBTransaction
  ]);
}
function O() {
  return M || (M = [
    IDBCursor.prototype.advance,
    IDBCursor.prototype.continue,
    IDBCursor.prototype.continuePrimaryKey
  ]);
}
const g = /* @__PURE__ */ new WeakMap(), w = /* @__PURE__ */ new WeakMap(), l = /* @__PURE__ */ new WeakMap();
function v(e) {
  const t = new Promise((n, r) => {
    const o = () => {
      e.removeEventListener("success", s), e.removeEventListener("error", a);
    }, s = () => {
      n(d(e.result)), o();
    }, a = () => {
      r(e.error), o();
    };
    e.addEventListener("success", s), e.addEventListener("error", a);
  });
  return l.set(t, e), t;
}
function _(e) {
  if (g.has(e))
    return;
  const t = new Promise((n, r) => {
    const o = () => {
      e.removeEventListener("complete", s), e.removeEventListener("error", a), e.removeEventListener("abort", a);
    }, s = () => {
      n(), o();
    }, a = () => {
      r(e.error || new DOMException("AbortError", "AbortError")), o();
    };
    e.addEventListener("complete", s), e.addEventListener("error", a), e.addEventListener("abort", a);
  });
  g.set(e, t);
}
let D = {
  get(e, t, n) {
    if (e instanceof IDBTransaction) {
      if (t === "done")
        return g.get(e);
      if (t === "store")
        return n.objectStoreNames[1] ? void 0 : n.objectStore(n.objectStoreNames[0]);
    }
    return d(e[t]);
  },
  set(e, t, n) {
    return e[t] = n, !0;
  },
  has(e, t) {
    return e instanceof IDBTransaction && (t === "done" || t === "store") ? !0 : t in e;
  }
};
function T(e) {
  D = e(D);
}
function j(e) {
  return O().includes(e) ? function(...t) {
    return e.apply(b(this), t), d(this.request);
  } : function(...t) {
    return d(e.apply(b(this), t));
  };
}
function R(e) {
  return typeof e == "function" ? j(e) : (e instanceof IDBTransaction && _(e), p(e, k()) ? new Proxy(e, D) : e);
}
function d(e) {
  if (e instanceof IDBRequest)
    return v(e);
  if (w.has(e))
    return w.get(e);
  const t = R(e);
  return t !== e && (w.set(e, t), l.set(t, e)), t;
}
const b = (e) => l.get(e);
function V(e, t, { blocked: n, upgrade: r, blocking: o, terminated: s } = {}) {
  const a = indexedDB.open(e, t), f = d(a);
  return r && a.addEventListener("upgradeneeded", (i) => {
    r(d(a.result), i.oldVersion, i.newVersion, d(a.transaction), i);
  }), n && a.addEventListener("blocked", (i) => n(
    // Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
    i.oldVersion,
    i.newVersion,
    i
  )), f.then((i) => {
    s && i.addEventListener("close", () => s()), o && i.addEventListener("versionchange", (u) => o(u.oldVersion, u.newVersion, u));
  }).catch(() => {
  }), f;
}
const q = ["get", "getKey", "getAll", "getAllKeys", "count"], F = ["put", "add", "delete", "clear"], m = /* @__PURE__ */ new Map();
function S(e, t) {
  if (!(e instanceof IDBDatabase && !(t in e) && typeof t == "string"))
    return;
  if (m.get(t))
    return m.get(t);
  const n = t.replace(/FromIndex$/, ""), r = t !== n, o = F.includes(n);
  if (
    // Bail if the target doesn't exist on the target. Eg, getAll isn't in Edge.
    !(n in (r ? IDBIndex : IDBObjectStore).prototype) || !(o || q.includes(n))
  )
    return;
  const s = async function(a, ...f) {
    const i = this.transaction(a, o ? "readwrite" : "readonly");
    let u = i.store;
    return r && (u = u.index(f.shift())), (await Promise.all([
      u[n](...f),
      o && i.done
    ]))[0];
  };
  return m.set(t, s), s;
}
T((e) => ({
  ...e,
  get: (t, n, r) => S(t, n) || e.get(t, n, r),
  has: (t, n) => !!S(t, n) || e.has(t, n)
}));
const W = ["continue", "continuePrimaryKey", "advance"], x = {}, B = /* @__PURE__ */ new WeakMap(), L = /* @__PURE__ */ new WeakMap(), K = {
  get(e, t) {
    if (!W.includes(t))
      return e[t];
    let n = x[t];
    return n || (n = x[t] = function(...r) {
      B.set(this, L.get(this)[t](...r));
    }), n;
  }
};
async function* N(...e) {
  let t = this;
  if (t instanceof IDBCursor || (t = await t.openCursor(...e)), !t)
    return;
  t = t;
  const n = new Proxy(t, K);
  for (L.set(n, t), l.set(n, b(t)); t; )
    yield n, t = await (B.get(n) || t.continue()), B.delete(n);
}
function A(e, t) {
  return t === Symbol.asyncIterator && p(e, [IDBIndex, IDBObjectStore, IDBCursor]) || t === "iterate" && p(e, [IDBIndex, IDBObjectStore]);
}
T((e) => ({
  ...e,
  get(t, n, r) {
    return A(t, n) ? N : e.get(t, n, r);
  },
  has(t, n) {
    return A(t, n) || e.has(t, n);
  }
}));
let I = null;
async function y() {
  return I || (I = V("AutoEOD-Extension-DB", 1, {
    upgrade(e) {
      e.createObjectStore("sync_queue", { keyPath: "payload.externalId" });
    }
  })), I;
}
async function $(e) {
  const t = await y(), n = await t.get("sync_queue", e.externalId);
  await t.put("sync_queue", {
    payload: e,
    addedAt: Date.now(),
    retryCount: n ? n.retryCount : 0,
    nextRetryAt: 0
    // Immediately retryable
  });
}
async function z() {
  const t = await (await y()).getAll("sync_queue"), n = Date.now();
  return t.filter((r) => r.nextRetryAt <= n);
}
async function C(e) {
  await (await y()).delete("sync_queue", e);
}
async function J(e, t, n) {
  const r = await y(), o = await r.get("sync_queue", e);
  o && await r.put("sync_queue", {
    ...o,
    retryCount: t,
    nextRetryAt: n
  });
}
async function E() {
  return (await chrome.storage.local.get("apiToken")).apiToken || null;
}
function Q() {
  return "https://autoeod-production.up.railway.app/api/extension/activity";
}
const U = 10, X = 5e3;
async function h() {
  const e = await z();
  if (e.length === 0) return;
  const t = await E();
  if (!t) {
    c("!", "#71717a");
    return;
  }
  let n = !1;
  for (const r of e)
    if (await Y(r.payload, t))
      await C(r.payload.externalId);
    else {
      n = !0;
      const s = r.retryCount + 1;
      if (s >= U)
        await C(r.payload.externalId);
      else {
        const a = X * Math.pow(2, s);
        await J(r.payload.externalId, s, Date.now() + a);
      }
    }
  n ? (c("!", "#ef4444"), chrome.alarms.create("retrySync", { delayInMinutes: 1 })) : (c("✓", "#22c55e"), await chrome.storage.local.set({ lastSync: (/* @__PURE__ */ new Date()).toISOString() }));
}
async function Y(e, t) {
  try {
    const n = await fetch(Q(), {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${t}`
      },
      body: JSON.stringify({ conversations: [e] })
    });
    return n.status === 401 ? (await chrome.storage.local.remove("apiToken"), c("!", "#ef4444"), !1) : !!n.ok;
  } catch (n) {
    return console.error("Network error syncing payload:", n), !1;
  }
}
function c(e, t) {
  chrome.action.setBadgeText({ text: e }), chrome.action.setBadgeBackgroundColor({ color: t });
}
chrome.runtime.onMessage.addListener((e, t, n) => {
  if (e.type === "ACTIVITY_UPDATE") {
    const r = e.payload;
    t.tab && (r.tabId = t.tab.id, r.windowId = t.tab.windowId), $(r).then(() => {
      h();
    }).catch((o) => {
      console.error("Failed to enqueue payload:", o);
    }), n({ status: "queued" });
  }
  return !0;
});
chrome.alarms.onAlarm.addListener((e) => {
  e.name === "retrySync" && h();
});
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create("retrySync", { periodInMinutes: 1 }), h();
});
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("retrySync", { periodInMinutes: 1 }), E().then((e) => {
    e ? c("✓", "#22c55e") : c("!", "#71717a");
  });
});
E().then((e) => {
  e ? c("✓", "#22c55e") : c("!", "#71717a"), h();
});
