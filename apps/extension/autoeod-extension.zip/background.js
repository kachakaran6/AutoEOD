const I = (e, t) => t.some((n) => e instanceof n);
let P, x;
function F() {
  return P || (P = [
    IDBDatabase,
    IDBObjectStore,
    IDBIndex,
    IDBCursor,
    IDBTransaction
  ]);
}
function V() {
  return x || (x = [
    IDBCursor.prototype.advance,
    IDBCursor.prototype.continue,
    IDBCursor.prototype.continuePrimaryKey
  ]);
}
const S = /* @__PURE__ */ new WeakMap(), D = /* @__PURE__ */ new WeakMap(), m = /* @__PURE__ */ new WeakMap();
function U(e) {
  const t = new Promise((n, r) => {
    const o = () => {
      e.removeEventListener("success", a), e.removeEventListener("error", i);
    }, a = () => {
      n(f(e.result)), o();
    }, i = () => {
      r(e.error), o();
    };
    e.addEventListener("success", a), e.addEventListener("error", i);
  });
  return m.set(t, e), t;
}
function K(e) {
  if (S.has(e))
    return;
  const t = new Promise((n, r) => {
    const o = () => {
      e.removeEventListener("complete", a), e.removeEventListener("error", i), e.removeEventListener("abort", i);
    }, a = () => {
      n(), o();
    }, i = () => {
      r(e.error || new DOMException("AbortError", "AbortError")), o();
    };
    e.addEventListener("complete", a), e.addEventListener("error", i), e.addEventListener("abort", i);
  });
  S.set(e, t);
}
let B = {
  get(e, t, n) {
    if (e instanceof IDBTransaction) {
      if (t === "done")
        return S.get(e);
      if (t === "store")
        return n.objectStoreNames[1] ? void 0 : n.objectStore(n.objectStoreNames[0]);
    }
    return f(e[t]);
  },
  set(e, t, n) {
    return e[t] = n, !0;
  },
  has(e, t) {
    return e instanceof IDBTransaction && (t === "done" || t === "store") ? !0 : t in e;
  }
};
function _(e) {
  B = e(B);
}
function $(e) {
  return V().includes(e) ? function(...t) {
    return e.apply(A(this), t), f(this.request);
  } : function(...t) {
    return f(e.apply(A(this), t));
  };
}
function z(e) {
  return typeof e == "function" ? $(e) : (e instanceof IDBTransaction && K(e), I(e, F()) ? new Proxy(e, B) : e);
}
function f(e) {
  if (e instanceof IDBRequest)
    return U(e);
  if (D.has(e))
    return D.get(e);
  const t = z(e);
  return t !== e && (D.set(e, t), m.set(t, e)), t;
}
const A = (e) => m.get(e);
function G(e, t, { blocked: n, upgrade: r, blocking: o, terminated: a } = {}) {
  const i = indexedDB.open(e, t), d = f(i);
  return r && i.addEventListener("upgradeneeded", (c) => {
    r(f(i.result), c.oldVersion, c.newVersion, f(i.transaction), c);
  }), n && i.addEventListener("blocked", (c) => n(
    // Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
    c.oldVersion,
    c.newVersion,
    c
  )), d.then((c) => {
    a && c.addEventListener("close", () => a()), o && c.addEventListener("versionchange", (l) => o(l.oldVersion, l.newVersion, l));
  }).catch(() => {
  }), d;
}
const H = ["get", "getKey", "getAll", "getAllKeys", "count"], J = ["put", "add", "delete", "clear"], b = /* @__PURE__ */ new Map();
function L(e, t) {
  if (!(e instanceof IDBDatabase && !(t in e) && typeof t == "string"))
    return;
  if (b.get(t))
    return b.get(t);
  const n = t.replace(/FromIndex$/, ""), r = t !== n, o = J.includes(n);
  if (
    // Bail if the target doesn't exist on the target. Eg, getAll isn't in Edge.
    !(n in (r ? IDBIndex : IDBObjectStore).prototype) || !(o || H.includes(n))
  )
    return;
  const a = async function(i, ...d) {
    const c = this.transaction(i, o ? "readwrite" : "readonly");
    let l = c.store;
    return r && (l = l.index(d.shift())), (await Promise.all([
      l[n](...d),
      o && c.done
    ]))[0];
  };
  return b.set(t, a), a;
}
_((e) => ({
  ...e,
  get: (t, n, r) => L(t, n) || e.get(t, n, r),
  has: (t, n) => !!L(t, n) || e.has(t, n)
}));
const Q = ["continue", "continuePrimaryKey", "advance"], O = {}, E = /* @__PURE__ */ new WeakMap(), j = /* @__PURE__ */ new WeakMap(), X = {
  get(e, t) {
    if (!Q.includes(t))
      return e[t];
    let n = O[t];
    return n || (n = O[t] = function(...r) {
      E.set(this, j.get(this)[t](...r));
    }), n;
  }
};
async function* Y(...e) {
  let t = this;
  if (t instanceof IDBCursor || (t = await t.openCursor(...e)), !t)
    return;
  t = t;
  const n = new Proxy(t, X);
  for (j.set(n, t), m.set(n, A(t)); t; )
    yield n, t = await (E.get(n) || t.continue()), E.delete(n);
}
function k(e, t) {
  return t === Symbol.asyncIterator && I(e, [IDBIndex, IDBObjectStore, IDBCursor]) || t === "iterate" && I(e, [IDBIndex, IDBObjectStore]);
}
_((e) => ({
  ...e,
  get(t, n, r) {
    return k(t, n) ? Y : e.get(t, n, r);
  },
  has(t, n) {
    return k(t, n) || e.has(t, n);
  }
}));
let g = null;
async function p() {
  return g || (g = G("AutoEOD-Extension-DB", 2, {
    upgrade(e, t) {
      t < 2 && (e.objectStoreNames.contains("sync_queue") && e.deleteObjectStore("sync_queue"), e.createObjectStore("sync_queue", { keyPath: "payload.id" }));
    }
  })), g;
}
async function R(e) {
  const t = await p(), n = await t.get("sync_queue", e.id);
  await t.put("sync_queue", {
    payload: e,
    addedAt: Date.now(),
    retryCount: n ? n.retryCount : 0,
    nextRetryAt: 0
    // Immediately retryable
  });
}
async function Z() {
  const t = await (await p()).getAll("sync_queue"), n = Date.now();
  return t.filter((r) => r.nextRetryAt <= n);
}
async function v(e) {
  await (await p()).delete("sync_queue", e);
}
async function ee(e, t, n) {
  const r = await p(), o = await r.get("sync_queue", e);
  o && await r.put("sync_queue", {
    ...o,
    retryCount: t,
    nextRetryAt: n
  });
}
async function T() {
  return (await chrome.storage.local.get("apiToken")).apiToken || null;
}
function W() {
  return "https://autoeod-production.up.railway.app/api/extension/activity";
}
const te = 10, ne = 5e3;
async function h() {
  const e = await Z();
  if (e.length === 0) return;
  const t = await T();
  if (!t) {
    y("!", "#71717a");
    return;
  }
  let n = !1;
  const r = e.map((o) => o.payload);
  if (r.length > 0)
    if (await re(r, t))
      for (const a of e)
        await v(a.payload.id);
    else {
      n = !0;
      for (const a of e) {
        const i = a.retryCount + 1;
        if (i >= te)
          await v(a.payload.id);
        else {
          const d = ne * Math.pow(2, i);
          await ee(a.payload.id, i, Date.now() + d);
        }
      }
    }
  n ? (y("!", "#ef4444"), chrome.alarms.create("retrySync", { delayInMinutes: 1 })) : (y("✓", "#22c55e"), await chrome.storage.local.set({ lastSync: (/* @__PURE__ */ new Date()).toISOString() }));
}
async function re(e, t) {
  try {
    let n = W();
    n.endsWith("/activity") ? n = n.replace("/activity", "/browser-activity") : n = `${n}/browser-activity`;
    const r = await fetch(n, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${t}`
      },
      body: JSON.stringify({ activities: e })
    });
    return r.status === 401 ? (await chrome.storage.local.remove("apiToken"), y("!", "#ef4444"), !1) : !!r.ok;
  } catch (n) {
    return console.error("Network error syncing payload:", n), !1;
  }
}
function y(e, t) {
  chrome.action.setBadgeText({ text: e }), chrome.action.setBadgeBackgroundColor({ color: t });
}
let s = null, w = !0, u = null;
async function M() {
  const e = await T();
  if (e)
    try {
      let t = W();
      t.endsWith("/activity") ? t = t.replace("/extension/activity", "/extension-settings") : t = `${t}/extension-settings`;
      const n = await fetch(t, {
        headers: { Authorization: `Bearer ${e}` }
      });
      n.ok && (u = await n.json(), u.globalPaused ? (w = !1, y("||", "#71717a")) : (w = !0, y("✓", "#22c55e")));
    } catch {
    }
}
async function C(e = Date.now()) {
  if (!s) return;
  if (!w) {
    s = null;
    return;
  }
  const t = e - s.openedAt, n = Math.floor(t / 1e3);
  n >= 2 && (await R({
    id: crypto.randomUUID(),
    domain: s.domain,
    url: s.url,
    pageTitle: s.title,
    tabOpenedAt: new Date(s.openedAt).toISOString(),
    tabClosedAt: new Date(e).toISOString(),
    durationSeconds: n,
    captureTier: 0
  }), h()), s = null;
}
async function q(e, t) {
  if (await C(), !!w)
    try {
      const n = await chrome.tabs.get(e);
      if (n && n.url && n.url.startsWith("http")) {
        const r = new URL(n.url);
        if (u != null && u.excludedDomains && u.excludedDomains.includes(r.hostname))
          return;
        s = {
          tabId: e,
          windowId: t,
          url: n.url,
          domain: r.hostname,
          title: n.title || r.hostname,
          openedAt: Date.now()
        };
      }
    } catch {
    }
}
chrome.tabs.onActivated.addListener(async (e) => {
  (await chrome.windows.get(e.windowId)).focused && await q(e.tabId, e.windowId);
});
chrome.windows.onFocusChanged.addListener(async (e) => {
  if (e === chrome.windows.WINDOW_ID_NONE)
    await C();
  else {
    const t = await chrome.tabs.query({ active: !0, windowId: e });
    t.length > 0 && t[0].id && await q(t[0].id, e);
  }
});
chrome.tabs.onUpdated.addListener(async (e, t, n) => {
  if (s && s.tabId === e && t.url) {
    if (await C(), t.url.startsWith("http")) {
      const r = new URL(t.url);
      s = {
        tabId: e,
        windowId: n.windowId,
        url: t.url,
        domain: r.hostname,
        title: n.title || r.hostname,
        openedAt: Date.now()
      };
    }
  } else s && s.tabId === e && t.title && (s.title = t.title);
});
chrome.runtime.onMessage.addListener((e, t, n) => {
  if (e.type === "ACTIVITY_UPDATE") {
    const r = e.payload;
    t.tab && (r.tabId = t.tab.id, r.windowId = t.tab.windowId), R(r).then(() => {
      h();
    }).catch((o) => {
      console.error("Failed to enqueue payload:", o);
    }), n({ status: "queued" });
  } else if (e.type === "GET_RECORDING_STATE")
    n({ isRecording: w });
  else if (e.type === "CHECK_TIER_1") {
    const { domain: r } = e.payload;
    let o = !1;
    u && (u.excludedDomains && u.excludedDomains.includes(r) ? o = !1 : (u.tier1GlobalDefault || u.tier1DomainAllowlist && u.tier1DomainAllowlist.includes(r)) && (o = !0)), n({ allowed: o });
  }
  return !0;
});
chrome.alarms.onAlarm.addListener((e) => {
  e.name === "retrySync" ? h() : e.name === "fetchSettings" && M();
});
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create("retrySync", { periodInMinutes: 1 }), chrome.alarms.create("fetchSettings", { periodInMinutes: 5 }), h(), M();
});
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("retrySync", { periodInMinutes: 1 }), chrome.alarms.create("fetchSettings", { periodInMinutes: 5 }), N();
});
N();
async function N() {
  await T() ? await M() : y("!", "#71717a"), h();
}
